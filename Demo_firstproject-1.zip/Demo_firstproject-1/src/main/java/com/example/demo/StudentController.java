package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/api/stu")
public class StudentController {
	
	@Autowired
	public StudentRepositary repo;
	
	
	 @PostMapping
	    public Studententity createUser(@RequestBody Studententity user) {
	        return repo.save(user);
	    }

	    @GetMapping
	    public List<Studententity> getAllUsers() {
	        return repo.findAll();
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<Studententity> getUserById(@PathVariable int id) {
	        Optional<Studententity> user = repo.findById(id);
	        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	    }
	
	

}
